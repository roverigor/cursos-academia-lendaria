Aulas Modulo 4: Delegacao Assistida
	4.1 QUICK WIN: Delegacao Express
		Duracao: 15 min
		Tipo: Exercicio Guiado
		Resultado
			Briefing 5 elementos
			3 criterios de qualidade
			Prompt de validacao
			Proximo passo concreto
	4.2 Por Que Delegar Sempre Falha
		Duracao: 8 min
		Tipo: Problema
		Erros comuns
			Briefing incompleto
			Sem criterios claros
			Revisao manual de tudo
			Centralizar demais
	4.3 O Modelo de Delegacao Assistida
		Duracao: 8 min
		Tipo: Framework
		Conceito
			Pessoa executa
			IA valida
			Lider aprova excecoes
		Beneficios
			-80% revisoes manuais
			Qualidade consistente
			Escala sem gargalo
	4.4 Demo: Modelo Completo
		Duracao: 8 min
		Tipo: Demonstracao
		Fluxo real funcionando
	4.5 Exercicio: Seu Modelo de Delegacao
		Duracao: 5 + 35 min
		Tipo: Pratica
		Entregavel: Modelo completo
	4.6 Como Treinar a Pessoa + IA
		Duracao: 6 min
		Tipo: Treinamento
		Passos
			Explicar o modelo
			Treinar uso do prompt
			Acompanhar primeiras execucoes
			Ajustar criterios
	4.7 Validacao + Proximos Passos
		Duracao: 6 min
		Tipo: Fechamento
		Conexao com Modulo 5
