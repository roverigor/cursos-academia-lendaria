Modulo 3: SOPs Inteligentes - Transformar Pessoas em Sistema
	Ficha Tecnica
		Duracao: 88 minutos
		7 aulas
		Nivel Bloom: 6 - Criar
		Entregavel: 1 SOP Inteligente Completo
	GPS do Modulo
		ORIGEM: Empresario com processos na cabeca ou documentos estaticos
		DESTINO: 1 SOP Inteligente completo com prompt de IA, testado
		ROTA: Quick Win > Problema > Estrutura > Demo > Build > Teste > Validacao
	Quick Win (15 min)
		Objetivo do processo em 1 frase
		Passo a passo de 5 etapas
		3 criterios de qualidade
		Prompt de validacao basico funcional
	Aulas
		3.1 QUICK WIN: SOP Express
			15 min | Exercicio Guiado
		3.2 Por Que SOPs Tradicionais Falham
			6 min | Problema
		3.3 Estrutura do SOP Inteligente
			8 min | Framework
			5 componentes essenciais
		3.4 Demo: SOP Completo
			8 min | Demonstracao
		3.5 Exercicio: Seu SOP Inteligente
			5 + 35 min | Pratica
		3.6 Como Testar se o SOP Funciona
			5 min | Validacao
		3.7 Validacao + Proximos Passos
			6 min | Fechamento
	Entregaveis
		SOP Inteligente Completo (5 componentes)
		Print do prompt testado
		Feedback de quem testou
