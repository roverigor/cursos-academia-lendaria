Trilha 1: Pessoas & Processos
	Visao Geral
		Duracao: ~7.5 horas
		36 aulas em 5 modulos
		100% Assincrono
		5 Quick Wins (resultado em 15 min)
	Modulo 1
		Onde Sua Empresa Depende de Pessoas
		8 aulas | 87 min
		Entregavel: Mapa de Dependencia Humana
	Modulo 2
		Funcoes Nao Trabalham, Decisoes Trabalham
		7 aulas | 84 min
		Entregavel: Matriz Funcao x Decisao
	Modulo 3
		SOPs Inteligentes
		7 aulas | 88 min
		Entregavel: 1 SOP Inteligente Completo
	Modulo 4
		Delegar Sem Virar Gargalo
		7 aulas | 91 min
		Entregavel: 1 Modelo de Delegacao Assistida
	Modulo 5
		Pessoas Custam Dinheiro
		7 aulas | 102 min
		Entregavel: Analise ROI + Plano 30 dias
	Jornada de Transformacao
		ANTES: Empresa depende de pessoas
		DEPOIS: Empresa depende de sistemas
