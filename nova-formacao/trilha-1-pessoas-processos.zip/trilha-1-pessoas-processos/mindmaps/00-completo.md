Trilha 1: Pessoas & Processos
	Modulo 1: Onde Sua Empresa Depende de Pessoas
		Entregavel: Mapa de Dependencia Humana
		Duracao: 87 min | 8 aulas
		Aulas
			1.1 QUICK WIN: Diagnostico Relampago (15 min)
			1.2 O Problema Nao Sao as Pessoas (6 min)
			1.3 Casos: Empresa Pequena (6 min)
			1.4 Casos: Empresa Media (7 min)
			1.5 Template: Mapa de Dependencia (5 min)
			1.6 Demo: Mapa Preenchido (6 min)
			1.7 Exercicio: Seu Mapa (34 min)
			1.8 Validacao + Proximos Passos (8 min)
	Modulo 2: Funcoes Nao Trabalham, Decisoes Trabalham
		Entregavel: Matriz Funcao x Decisao
		Duracao: 84 min | 7 aulas
		Aulas
			2.1 QUICK WIN: 3 Decisoes Automatizaveis (15 min)
			2.2 O Erro de Mapear Tarefas (6 min)
			2.3 Os 3 Tipos de Decisao (8 min)
			2.4 Exemplos: Decisoes Automatizadas (6 min)
			2.5 Template: Matriz Funcao x Decisao (5 min)
			2.6 Demo: Matriz Preenchida (6 min)
			2.7 Exercicio + Validacao (38 min)
	Modulo 3: SOPs Inteligentes
		Entregavel: 1 SOP Inteligente Completo
		Duracao: 88 min | 7 aulas
		Aulas
			3.1 QUICK WIN: SOP Express (15 min)
			3.2 Por Que SOPs Tradicionais Falham (6 min)
			3.3 Estrutura do SOP Inteligente (8 min)
			3.4 Demo: SOP Completo (8 min)
			3.5 Exercicio: Seu SOP Inteligente (40 min)
			3.6 Como Testar se o SOP Funciona (5 min)
			3.7 Validacao + Proximos Passos (6 min)
	Modulo 4: Delegar Sem Virar Gargalo
		Entregavel: 1 Modelo de Delegacao Assistida
		Duracao: 91 min | 7 aulas
		Aulas
			4.1 QUICK WIN: Delegacao Express (15 min)
			4.2 Por Que Delegar Sempre Falha (8 min)
			4.3 O Modelo de Delegacao Assistida (8 min)
			4.4 Demo: Modelo Completo (8 min)
			4.5 Exercicio: Seu Modelo de Delegacao (40 min)
			4.6 Como Treinar a Pessoa + IA (6 min)
			4.7 Validacao + Proximos Passos (6 min)
	Modulo 5: Pessoas Custam Dinheiro - Decida com Numeros
		Entregavel: Analise ROI + Plano 30 dias
		Duracao: 102 min | 7 aulas
		Aulas
			5.1 QUICK WIN: Custo Real de 1 Funcao (15 min)
			5.2 O Custo Real de um Funcionario (10 min)
			5.3 Como Medir Valor Gerado (10 min)
			5.4 Framework de Decisao (8 min)
			5.5 Demo: Analise de ROI Completa (8 min)
			5.6 Exercicio: Sua Analise de ROI (41 min)
			5.7 Plano de Acao + Fechamento da Trilha (10 min)
	Entregaveis da Trilha
		1. Mapa de Dependencia Humana
		2. Matriz Funcao x Decisao
		3. 1 SOP Inteligente
		4. 1 Modelo de Delegacao
		5. Analise ROI + Plano 30 dias
	Metricas
		Duracao Total: ~452 min (~7.5h)
		36 aulas
		5 Quick Wins
		100% Assincrono
