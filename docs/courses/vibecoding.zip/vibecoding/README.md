# Vibecoding - Criação de Apps Sem Código com IA

**Instrutor:** José Carlos Amorim
**Duração:** 2 horas
**Nível:** Iniciante (Zero programação)
**Ferramentas:** Bolt.new (Lovable) + Supabase + IA

---

## 🎯 Para Quem é Este Curso

Empreendedores digitais (25-45 anos) e profissionais em transição que:
- ❌ Não sabem programar (e não precisam aprender!)
- 🚀 Enxergam IA como ponte entre linguagem natural e código
- 💰 Querem monetizar através de criação de apps/MicroSaaS
- ⏰ Têm 1-2h para dedicar a conteúdo desafiador e instigante

**Barreira Mental que Vamos Quebrar:**
"É como colocar um agricultor que capina com enxada para operar uma máquina de capinagem. Ele não entende como a máquina funciona e por isso não vê valor."

Neste curso, você vai **VER a máquina funcionando** antes de entender a teoria. Vai criar apps de verdade em minutos.

---

## 🎁 O Que Você Vai Conquistar

Ao final deste curso, você terá:

✅ **Autonomia** para criar o que sempre imaginou, mas não tinha como fazer por não saber código
✅ **3 aplicações funcionais** criadas sem escrever 1 linha de código
✅ **1 MicroSaaS funcional** pronto para comercializar
✅ Capacidade de **transformar ideia em protótipo validável**
✅ Framework replicável para **prestar serviço** com esse conhecimento

---

## 📚 Estrutura do Curso

### **MÓDULO 1: DO ZERO AO PRIMEIRO APP** (30 min)
Quebra a barreira mental + primeira vitória rápida

- **Lesson 1.1:** A Máquina que Você Não Sabia Operar (10 min)
- **Lesson 1.2:** Mapa da Clareza - Seu Primeiro App Funcional (20 min)

### **MÓDULO 2: ARSENAL NO-CODE** (60 min)
Domina Bolt.new + Supabase + cria 3 apps completos

- **Lesson 2.1:** Bolt.new - De Protótipo a Produção (15 min)
- **Lesson 2.2:** Supabase - O Armário que Lembra Tudo (20 min)
- **Lesson 2.3:** Auth - O Porteiro do Seu App (25 min)

### **MÓDULO 3: VIRANDO DINHEIRO** (30 min)
Transforma skill em MicroSaaS comercializável

- **Lesson 3.1:** Hub de GPTs - Seu Primeiro MicroSaaS (20 min)
- **Lesson 3.2:** Landing que Vende no Automático (10 min)

---

## 🛠️ Ferramentas Necessárias

**Obrigatórias:**
- Claude.ai (gratuito)
- Bolt.new (gratuito com limitações, pago $20/mês recomendado)
- Supabase (gratuito)
- Conta GitHub (gratuito)

**Opcionais:**
- OpenAI API ($5 mínimo de crédito)
- Stripe (para pagamentos no MicroSaaS)

---

## 💰 Potencial de Monetização

**Casos Reais do José Carlos:**

1. **Anamnese Digital para Fisioterapeuta:** R$ 1.000 (primeiro projeto)
2. **Formulário Inteligente para Médico:** R$ 3.500 (segundo projeto)
3. **MicroSaaS Hub de GPTs:** Potencial de R$ 97-497/mês por cliente

**Framework Replicável:**
Você pode usar o que aprende aqui para criar soluções sob demanda para clientes ou criar seus próprios produtos digitais.

---

## 🎤 Sobre o Instrutor

**José Carlos Amorim** é nexialista (entende de tudo um pouco e junta as coisas para criar resultados) especializado em IA e criação de interfaces visuais.

**Formação:**
- Leaders of Learning - Harvard
- AI for Business - IBM
- AI Fluency - Anthropic
- Técnico em Mecatrônica (Gillette - Engenharia de Qualidade)
- 5.000+ horas ao vivo em telejornalismo
- 3.000+ reportagens criadas

**Filosofia:**
> "No-Code é democratização do conhecimento técnico. É a forma mais genuína de possibilitar que quem realmente tem dor cria remédio para o problema."

> "Empreender é a única chave para quem quer autonomia e liberdade para viver a única vida que tem."

---

## 🎯 Metodologia: "Ver para Crer"

Este curso segue a metodologia do José Carlos:

1. **Metáfora Visual Primeiro** → Casa FullStack (HTML=tijolos, CSS=pintura, JS=elétrica)
2. **Do Concreto ao Abstrato** → Ver funcionando ANTES da teoria
3. **Hands-On Total** → 80% prática, 20% explicação
4. **Linguagem Adaptativa** → Termos técnicos + metáforas em tempo real
5. **Celebração de Vitórias** → Cada app criado é uma conquista

---

## 📂 Arquivos do Curso

```
docs/courses/vibecoding/
├── README.md                  # Este arquivo
├── course-outline.md          # Estrutura completa
├── curriculum.yaml            # Metadados estruturados
├── lessons/
│   ├── 1.1-maquina-que-nao-sabia-operar.md
│   ├── 1.2-mapa-da-clareza.md
│   ├── 2.1-bolt-prototipo-producao.md
│   ├── 2.2-supabase-armario.md
│   ├── 2.3-auth-porteiro.md
│   ├── 3.1-hub-gpts-microsaas.md
│   └── 3.2-landing-vende-automatico.md
├── assessments/
│   ├── quiz-modulo-1.yaml
│   ├── quiz-modulo-2.yaml
│   └── projeto-final-microsaas.md
└── resources/
    ├── checklist-setup-ferramentas.md
    ├── biblioteca-prompts.md
    ├── template-microsaas-canvas.md
    └── troubleshooting-comum.md
```

---

## 🚀 Como Usar Este Curso

1. **Configuração Inicial** (5 min): Crie contas nas ferramentas necessárias
2. **Siga a Ordem dos Módulos**: Cada lesson depende da anterior
3. **Faça os Projetos Práticos**: Não pule! A mágica acontece fazendo
4. **Consulte os Resources**: Templates e checklists estão prontos para uso
5. **Itere, Itere, Itere**: As IAs raramente acertam de primeira - isso é normal!

---

## 📞 Suporte & Comunidade

**Problemas Comuns?** → Veja `resources/troubleshooting-comum.md`
**Dúvidas Técnicas?** → Entre na comunidade do curso
**Quer Compartilhar Seu App?** → Mostre no grupo!

---

## 🎓 Certificado de Conclusão

Para receber o certificado, você precisa:
- ✅ Completar os 3 módulos
- ✅ Criar os 3 apps práticos (Mapa da Clareza, App com Auth, Hub de GPTs)
- ✅ Submeter seu MicroSaaS final

---

**Pronto para começar?** → Vá para `lessons/1.1-maquina-que-nao-sabia-operar.md`

---

*Curso criado em 2025-10-15 | Versão 1.0*
