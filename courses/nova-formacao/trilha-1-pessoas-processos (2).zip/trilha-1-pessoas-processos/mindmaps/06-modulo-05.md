Modulo 5: Pessoas Custam Dinheiro - Decida com Numeros
	Ficha Tecnica
		Duracao: 102 minutos
		7 aulas
		Nivel Bloom: 5 - Avaliar
		Proporcao: 70% pratica / 30% teoria
		Entregavel: Analise ROI + Plano 30 dias
	GPS do Modulo
		ORIGEM: Empresario que decide sobre pessoas com base em emocao
		DESTINO: Analise de ROI com decisao racional (manter, automatizar, reestruturar)
		ROTA: Quick Win > Custo Real > Valor Gerado > Framework > Demo > Exercicio > Plano
	Quick Win (15 min)
		Custo REAL de 1 funcao calculado
		Valor gerado estimado
		ROI simples calculado
		Decisao inicial definida
	Aulas
		5.1 QUICK WIN: Custo Real de 1 Funcao
			15 min | Exercicio Guiado
		5.2 O Custo Real de um Funcionario
			10 min | Conceito + Pratica
		5.3 Como Medir Valor Gerado
			10 min | Conceito + Pratica
		5.4 Framework de Decisao
			8 min | Framework
			Manter
			Otimizar
			Automatizar
		5.5 Demo: Analise de ROI Completa
			8 min | Demonstracao
		5.6 Exercicio: Sua Analise de ROI
			5 + 36 min | Pratica em 3 blocos
		5.7 Plano de Acao + Fechamento da Trilha
			10 min | Fechamento
	Entregaveis
		Analise de ROI de pelo menos 3 funcoes
		Plano de acao 30 dias
		Projeto final da Trilha 1 completo
