Modulo 4: Delegar Sem Virar Gargalo
	Ficha Tecnica
		Duracao: 91 minutos
		7 aulas
		Nivel Bloom: 5 - Avaliar
		Entregavel: 1 Modelo de Delegacao Assistida
	GPS do Modulo
		ORIGEM: Empresario que delega e precisa revisar tudo, ou desistiu de delegar
		DESTINO: Modelo que elimina 80% das revisoes manuais
		ROTA: Quick Win > Por que falha > Modelo > Demo > Exercicio > Treinamento > Validacao
	Quick Win (15 min)
		Briefing com 5 elementos essenciais
		3 criterios de qualidade definidos
		Prompt de validacao basico funcional
		Proximo passo concreto identificado
	Aulas
		4.1 QUICK WIN: Delegacao Express
			15 min | Exercicio Guiado
		4.2 Por Que Delegar Sempre Falha
			8 min | Problema
		4.3 O Modelo de Delegacao Assistida
			8 min | Framework
		4.4 Demo: Modelo Completo
			8 min | Demonstracao
		4.5 Exercicio: Seu Modelo de Delegacao
			5 + 35 min | Pratica
		4.6 Como Treinar a Pessoa + IA
			6 min | Treinamento
		4.7 Validacao + Proximos Passos
			6 min | Fechamento
	Entregaveis
		Modelo de Delegacao Completo (5 componentes)
		Print do prompt de validacao testado
		1 acao concreta para essa semana
