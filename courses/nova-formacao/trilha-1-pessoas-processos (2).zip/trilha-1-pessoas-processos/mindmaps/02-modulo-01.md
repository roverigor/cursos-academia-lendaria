Modulo 1: Onde Sua Empresa Depende de Pessoas
	Ficha Tecnica
		Duracao: 87 minutos
		8 aulas
		Nivel Bloom: 4 - Analisar
		Entregavel: Mapa de Dependencia Humana
	GPS do Modulo
		ORIGEM: Empresario que "sente" dependencia mas nao quantifica
		DESTINO: Mapa completo + plano de acao para riscos criticos
		ROTA: Quick Win > Conceito > Exemplos > Template > Build > Validacao
	Quick Win (15 min)
		Lista de 5 funcoes criticas
		Classificacao de risco (Alto/Medio/Baixo)
		TOP 3 pontos de vulnerabilidade
		Custo estimado do maior risco em R$
	Aulas
		1.1 QUICK WIN: Diagnostico Relampago
			15 min | Exercicio Guiado
		1.2 O Problema Nao Sao as Pessoas
			6 min | Conceito
		1.3 Casos: Empresa Pequena
			6 min | Exemplos
		1.4 Casos: Empresa Media
			7 min | Exemplos
		1.5 Template: Mapa de Dependencia Completo
			5 min | Template
		1.6 Demo: Mapa Preenchido
			6 min | Demonstracao
		1.7 Exercicio: Seu Mapa
			4 + 30 min | Pratica
		1.8 Validacao + Proximos Passos
			8 min | Fechamento
	Materiais de Apoio
		Template Mapa de Dependencia (PDF/Excel)
		Prompt de validacao
		Checklist de validacao
