Aulas Modulo 1: Dependencia Humana
	1.1 QUICK WIN: Diagnostico Relampago
		Duracao: 15 min
		Tipo: Exercicio Guiado
		Resultado
			Lista 5 funcoes criticas
			Classificacao de risco
			TOP 3 vulnerabilidades
			Custo do maior risco
	1.2 O Problema Nao Sao as Pessoas
		Duracao: 6 min
		Tipo: Conceito
		Insight: Dependencia de pessoas = falta de sistema
	1.3 Casos: Empresa Pequena
		Duracao: 6 min
		Tipo: Exemplos Reais
		Cenario: Comercio, servicos, startups
	1.4 Casos: Empresa Media
		Duracao: 7 min
		Tipo: Exemplos Reais
		Cenario: Industria, tecnologia, franquias
	1.5 Template: Mapa de Dependencia Completo
		Duracao: 5 min
		Tipo: Template
		Componentes
			Funcoes criticas
			Nivel de dependencia
			Risco de saida
			Custo de substituicao
	1.6 Demo: Mapa Preenchido
		Duracao: 6 min
		Tipo: Demonstracao
		Exemplo real preenchido
	1.7 Exercicio: Seu Mapa
		Duracao: 4 + 30 min
		Tipo: Pratica Individual
		Entregavel: Mapa de Dependencia preenchido
	1.8 Validacao + Proximos Passos
		Duracao: 8 min
		Tipo: Fechamento
		Validacao com IA
		Conexao com Modulo 2
