Aulas Modulo 3: SOPs Inteligentes
	3.1 QUICK WIN: SOP Express
		Duracao: 15 min
		Tipo: Exercicio Guiado
		Resultado
			Objetivo em 1 frase
			5 etapas do processo
			3 criterios de qualidade
			Prompt de validacao
	3.2 Por Que SOPs Tradicionais Falham
		Duracao: 6 min
		Tipo: Problema
		Erros comuns
			Muito generico
			Desatualizado
			Sem criterios de qualidade
			Sem validacao
	3.3 Estrutura do SOP Inteligente
		Duracao: 8 min
		Tipo: Framework
		5 Componentes
			1. Objetivo claro
			2. Passo a passo
			3. Criterios de qualidade
			4. Excecoes e decisoes
			5. Prompt de validacao IA
	3.4 Demo: SOP Completo
		Duracao: 8 min
		Tipo: Demonstracao
		Exemplo real com todos os componentes
	3.5 Exercicio: Seu SOP Inteligente
		Duracao: 5 + 35 min
		Tipo: Pratica
		Entregavel: SOP completo testavel
	3.6 Como Testar se o SOP Funciona
		Duracao: 5 min
		Tipo: Validacao
		Metodo
			Dar para outra pessoa
			Observar execucao
			Coletar feedback
			Iterar
	3.7 Validacao + Proximos Passos
		Duracao: 6 min
		Tipo: Fechamento
		Conexao com Modulo 4
