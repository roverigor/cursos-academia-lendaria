Aulas Modulo 2: Funcoes x Decisoes
	2.1 QUICK WIN: 3 Decisoes Automatizaveis
		Duracao: 15 min
		Tipo: Exercicio Guiado
		Resultado
			5 decisoes repetitivas
			Classificacao E/T/O
			TOP 3 para automacao
			1 regra Se/Entao
	2.2 O Erro de Mapear Tarefas
		Duracao: 6 min
		Tipo: Conceito
		Insight: Tarefas sao consequencia de decisoes
	2.3 Os 3 Tipos de Decisao
		Duracao: 8 min
		Tipo: Conceito
		Piramide de Decisoes
			Estrategica (topo)
				Longo prazo
				Alto impacto
				Nao automatizavel
			Tatica (meio)
				Medio prazo
				Padronizavel
				Semi-automatizavel
			Operacional (base)
				Curto prazo
				Repetitiva
				100% automatizavel
	2.4 Exemplos: Decisoes Automatizadas
		Duracao: 6 min
		Tipo: Exemplos
		Por area
			Financeiro
			Comercial
			Operacoes
			RH
	2.5 Template: Matriz Funcao x Decisao
		Duracao: 5 min
		Tipo: Template
		Estrutura
			Funcao
			Decisoes que toma
			Tipo (E/T/O)
			Automatizavel?
	2.6 Demo: Matriz Preenchida
		Duracao: 6 min
		Tipo: Demonstracao
		Exemplo real
	2.7 Exercicio + Validacao
		Duracao: 8 + 30 min
		Tipo: Pratica + Fechamento
		Entregavel: Matriz completa
