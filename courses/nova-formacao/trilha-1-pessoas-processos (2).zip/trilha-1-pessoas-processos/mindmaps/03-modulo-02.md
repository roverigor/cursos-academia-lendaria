Modulo 2: Funcoes Nao Trabalham, Decisoes Trabalham
	Ficha Tecnica
		Duracao: 84 minutos
		7 aulas
		Nivel Bloom: 4 - Analisar
		Entregavel: Matriz Funcao x Decisao
	GPS do Modulo
		ORIGEM: Empresario que mapeia TAREFAS quando deveria mapear DECISOES
		DESTINO: Matriz completa com TOP 5 decisoes priorizadas para automacao
		ROTA: Quick Win > Conceito > Tipos > Exemplos > Build > Validacao
	Quick Win (15 min)
		Lista de 5 decisoes repetitivas
		Classificacao por tipo (E/T/O)
		TOP 3 candidatas a automacao
		1 regra Se/Entao escrita
	Aulas
		2.1 QUICK WIN: 3 Decisoes Automatizaveis
			15 min | Exercicio Guiado
		2.2 O Erro de Mapear Tarefas
			6 min | Conceito
		2.3 Os 3 Tipos de Decisao
			8 min | Conceito
			Estrategica
			Tatica
			Operacional
		2.4 Exemplos: Decisoes Automatizadas
			6 min | Exemplos
		2.5 Template: Matriz Funcao x Decisao
			5 min | Template
		2.6 Demo: Matriz Preenchida
			6 min | Demonstracao
		2.7 Exercicio + Validacao
			8 + 30 min | Pratica + Fechamento
	Materiais de Apoio
		Template Matriz Funcao x Decisao (PDF/Excel)
		Prompt de classificacao
		Exemplos de regras por area
