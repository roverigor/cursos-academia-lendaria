Aulas Modulo 5: ROI de Pessoas
	5.1 QUICK WIN: Custo Real de 1 Funcao
		Duracao: 15 min
		Tipo: Exercicio Guiado
		Resultado
			Custo REAL calculado
			Valor gerado estimado
			ROI simples
			Decisao inicial
	5.2 O Custo Real de um Funcionario
		Duracao: 10 min
		Tipo: Conceito + Pratica
		Componentes do custo
			Salario bruto
			Encargos (INSS, FGTS, ferias, 13o)
			Beneficios
			Infraestrutura
			Gestao/supervisao
			Custo de erro
		Formula: Custo Real = 1.8x a 2.5x salario
	5.3 Como Medir Valor Gerado
		Duracao: 10 min
		Tipo: Conceito + Pratica
		Metricas de valor
			Receita direta gerada
			Problemas evitados
			Tempo economizado
			Clientes retidos
	5.4 Framework de Decisao
		Duracao: 8 min
		Tipo: Framework
		Matriz ROI
			ROI > 3x: Manter e valorizar
			ROI 1-3x: Otimizar
			ROI < 1x: Automatizar ou reestruturar
	5.5 Demo: Analise de ROI Completa
		Duracao: 8 min
		Tipo: Demonstracao
		Caso real com numeros
	5.6 Exercicio: Sua Analise de ROI
		Duracao: 5 + 36 min
		Tipo: Pratica em Blocos
		3 blocos de 12 min
			Bloco 1: Funcao mais cara
			Bloco 2: Funcao mais critica
			Bloco 3: Funcao mais questionada
	5.7 Plano de Acao + Fechamento da Trilha
		Duracao: 10 min
		Tipo: Fechamento
		Entregaveis
			Analise ROI de 3 funcoes
			Plano 30 dias
			Projeto final Trilha 1
		Proxima Trilha: Ferramentas & Tecnologia
