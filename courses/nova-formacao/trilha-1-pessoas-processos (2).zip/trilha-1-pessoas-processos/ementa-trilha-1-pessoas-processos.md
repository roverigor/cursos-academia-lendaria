# EMENTA - Trilha 1: Pessoas & Processos

## Reducao de Custo | Academia Lendaria

---

> **Categoria:** Reducao de Custo
> **Duracao Total:** 6-8 horas (5 modulos)
> **Formato:** Hibrido (assincrono + sincrono)
> **Versao:** 1.0 | Dezembro 2025

---

# PARTE 1: FRAMEWORK GPS

## DESTINO (Para Onde o Aluno Vai)

### Promessa de Transformacao

> **"Multiplicar a produtividade da equipe em ate 10x, reduzir dependencia de pessoas, transformar conhecimento tacito em sistemas, e reduzir custo operacional/headcount sem perder performance."**

### Resultado Tangivel ao Final da Trilha

O aluno tera implementado:
- **1 Mapa de Dependencia Humana** - Visualizacao de riscos operacionais
- **1 Matriz Funcao x Decisao** - Identificacao de automacoes prioritarias
- **3+ SOPs Inteligentes** - Processos executaveis sem pessoa original
- **1 Modelo de Delegacao Assistida** - Sistema anti-microgestao
- **1 Analise de ROI de Pessoas** - Decisao racional sobre headcount

### Impacto no DRE

| Linha do DRE | Impacto Esperado |
|--------------|------------------|
| **Custo de Pessoal** | Reducao de 20-40% em tarefas repetitivas |
| **Custo Operacional** | Reducao de retrabalho e erros |
| **Tempo** | Economia de 10-20h/semana em decisoes repetitivas |
| **Risco** | Reducao de dependencia critica de pessoas |

### Destino Emocional (5 Por Ques)

```
"Quero reduzir custos com pessoas"
  → Por que? "Porque gasto muito com folha"
    → Por que importa? "Porque a margem esta apertada"
      → Por que isso incomoda? "Porque trabalho muito e sobra pouco"
        → Por que isso dói? "Porque quero liberdade financeira"
          → DESTINO REAL: "Quero ter um negocio que funcione SEM mim"
```

---

## ORIGEM (De Onde o Aluno Parte)

### Perfil do Aluno (ICP)

| Atributo | Valor |
|----------|-------|
| **Quem** | Empresario / Dono de negocio |
| **Faturamento** | R$ 50K - R$ 250K/mes |
| **Equipe** | 5-30 funcionarios |
| **Nivel tecnico** | Iniciante (usa ChatGPT basico) |
| **Tempo disponivel** | Escasso |

### Dores de Entrada

| Dor | Sintoma | Custo Oculto |
|-----|---------|--------------|
| "A empresa depende de mim" | Nao consegue tirar ferias | Burnout, estagnacao |
| "Se fulano sair, para tudo" | Conhecimento na cabeca de 1 pessoa | Risco operacional |
| "Delego e vira bagunca" | Microgestao constante | Tempo desperdicado |
| "Nao sei se vale manter ou demitir" | Decisao emocional | Custo desnecessario |
| "Processo so funciona com o dono" | Sem documentacao | Limite de escala |

### Pre-requisitos Obrigatorios

Antes de iniciar, o aluno DEVE ter:

- [ ] **Faturamento atual** documentado
- [ ] **Custo de folha** mapeado (mesmo que aproximado)
- [ ] **Objetivo de 30 dias** claro (ex: "reduzir 10h/semana em supervisao")
- [ ] **Metrica unica** escolhida (ex: horas/semana em microgestao)
- [ ] **Area piloto** selecionada (1 departamento ou 1 processo)
- [ ] **Acesso a ChatGPT/Claude** configurado

---

## ROTA (Caminho da Origem ao Destino)

### Visao Geral dos 5 Modulos

```
MODULO 1          MODULO 2          MODULO 3          MODULO 4          MODULO 5
Dependencia   →   Decisoes      →   SOPs          →   Delegacao     →   ROI
Humana            Automatizaveis    Inteligentes      Assistida         de Pessoas

[Diagnostico]     [Priorizacao]     [Documentacao]    [Execucao]        [Decisao]
```

### Timeline de Implementacao

| Modulo | Duracao | Entregavel | Prazo de Implementacao |
|--------|---------|------------|------------------------|
| 1 | 90 min | Mapa de Dependencia Humana | 48h |
| 2 | 90 min | Matriz Funcao x Decisao | 48h |
| 3 | 90 min | 1 SOP Inteligente | 48h |
| 4 | 90 min | Modelo de Delegacao Assistida | 48h |
| 5 | 90 min | Analise de ROI de Pessoas | 48h |

---

# PARTE 2: DETALHAMENTO DOS MODULOS

---

## MODULO 1: Onde Sua Empresa Depende de Pessoas (e Nao de Sistemas)

### Ficha Tecnica

| Atributo | Valor |
|----------|-------|
| **Duracao** | 90 minutos |
| **Bloom** | Nivel 4 - Analisar |
| **Formato** | Video (30min) + Build Sprint (60min) |

### Objetivo

Gerar **consciencia brutal** de dependencia humana e risco operacional.

### Diagnostico Central

> **"O problema nao sao pessoas fracas. O problema sao processos invisiveis, conhecimento nao documentado e decisoes humanas repetitivas."**

### Conteudo (Estrutura de Aula)

| Etapa | Duracao | Conteudo |
|-------|---------|----------|
| **1. Contexto de Negocio** | 5 min | "Qual linha do DRE isso mexe? → Custo + Risco" |
| **2. Conceito-chave** | 10 min | Dependencia ≠ pessoas ruins. E falta de sistema. |
| **3. Exemplos reais** | 10 min | Empresa pequena, media, servico |
| **4. Introducao ao Mapa** | 5 min | Template do Mapa de Dependencia Humana |
| **5. Build Sprint** | 45 min | Aluno preenche seu proprio Mapa |
| **6. Validacao** | 10 min | Checklist + Prompt de validacao |
| **7. Proxima acao 48h** | 5 min | Completar mapa + identificar top 3 riscos |

### Entregavel Obrigatorio

**Mapa de Dependencia Humana**, contendo:

| Coluna | Descricao |
|--------|-----------|
| **Funcao** | Nome do cargo/funcao |
| **Pessoa** | Quem ocupa hoje |
| **O que acontece se sair** | Impacto real no negocio |
| **Horas/semana** | Tempo dedicado |
| **Risco** | Baixo / Medio / Alto |

### Template

```
| Funcao | Pessoa | Se Sair... | Horas/Sem | Risco |
|--------|--------|------------|-----------|-------|
| Vendas | Maria  | Para pipeline | 40h | ALTO |
| Financeiro | Joao | Atrasa pgto | 20h | MEDIO |
| Atendimento | Ana | Clientes reclamam | 30h | ALTO |
```

### Checklist de Validacao

- [ ] Todas as funcoes criticas mapeadas
- [ ] Pelo menos 1 risco ALTO identificado
- [ ] Horas estimadas (nao "nao sei")
- [ ] Outra pessoa entende o mapa (clareza)

### Prompt IA (Validacao)

```
Com base nesta estrutura de empresa:
[colar lista de funcoes/pessoas]

Identifique:
1. Onde ha dependencia critica de pessoas
2. Onde decisoes sao sempre humanas
3. Onde a empresa para se alguem sair
4. Onde IA teria maior impacto imediato

Ordene por prioridade de risco.
```

### Erros Comuns a Evitar

| Erro | Por que e problema | Como evitar |
|------|-------------------|-------------|
| Mapear cargos, nao decisoes | Cargo nao mostra risco real | Perguntar "o que acontece se sair?" |
| Subestimar risco | "Ah, a gente da um jeito" | Quantificar em horas/dinheiro |
| Nao incluir o dono | Dono e maior dependencia | Incluir suas proprias funcoes |

---

## MODULO 2: Funcoes Nao Trabalham — Decisoes Trabalham

### Ficha Tecnica

| Atributo | Valor |
|----------|-------|
| **Duracao** | 90 minutos |
| **Bloom** | Nivel 4 - Analisar |
| **Formato** | Video (30min) + Build Sprint (60min) |

### Objetivo

Separar **trabalho humano real** de **decisao repetitiva automatizavel**.

### Conceito Central

> **"O erro classico: mapear tarefas, nao decisoes. Tarefas sao infinitas. Decisoes sao finitas e automatizaveis."**

### Tipos de Decisao

| Tipo | Exemplo | Automatizavel? |
|------|---------|----------------|
| **Estrategica** | Entrar em novo mercado | Nao (humano) |
| **Tatica** | Qual campanha priorizar | Parcial (IA + humano) |
| **Operacional** | Aprovar reembolso < R$ 100 | Sim (regra + IA) |

### Conteudo (Estrutura de Aula)

| Etapa | Duracao | Conteudo |
|-------|---------|----------|
| **1. Contexto de Negocio** | 5 min | "Quanto tempo/dia voce gasta decidindo coisas obvias?" |
| **2. O erro classico** | 10 min | Mapear tarefas vs mapear decisoes |
| **3. Tipos de decisao** | 10 min | Estrategica, Tatica, Operacional |
| **4. Como identificar decisao baseada em regra** | 5 min | Se tem "se/entao", e automatizavel |
| **5. Exemplos reais** | 10 min | Vendas, atendimento, operacao |
| **6. Build Sprint** | 45 min | Preencher Matriz Funcao x Decisao |
| **7. Proxima acao 48h** | 5 min | Listar 3 decisoes para automatizar |

### Entregavel Obrigatorio

**Matriz Funcao x Decisao**, contendo:

| Coluna | Descricao |
|--------|-----------|
| **Decisao** | O que e decidido |
| **Frequencia** | Diaria / Semanal / Mensal |
| **Impacto** | Baixo / Medio / Alto |
| **Tipo** | Estrategica / Tatica / Operacional |
| **Candidata a IA** | Sim / Nao |

### Template

```
| Decisao | Freq | Impacto | Tipo | IA? |
|---------|------|---------|------|-----|
| Aprovar desconto | Diaria | Medio | Operacional | SIM |
| Priorizar leads | Diaria | Alto | Tatica | SIM |
| Contratar senior | Mensal | Alto | Estrategica | NAO |
```

### Checklist de Validacao

- [ ] Pelo menos 10 decisoes listadas
- [ ] Classificacao completa (tipo + frequencia + impacto)
- [ ] >= 3 decisoes candidatas a automacao com IA
- [ ] Ligacao clara com funcoes do Modulo 1

### Prompt IA (Classificacao)

```
Classifique estas decisoes:
[lista de decisoes]

Para cada uma, diga:
- Tipo de decisao (estrategica/tatica/operacional)
- Frequencia (diaria/semanal/mensal)
- Se pode ser automatizada (sim/nao/parcial)
- Qual tipo de IA faria sentido (regras/LLM/ambos)
- Prioridade de automacao (1-5)
```

---

## MODULO 3: SOPs Inteligentes — Transformar Pessoas em Sistema

### Ficha Tecnica

| Atributo | Valor |
|----------|-------|
| **Duracao** | 90 minutos |
| **Bloom** | Nivel 6 - Criar |
| **Formato** | Video (30min) + Build Sprint (60min) |

### Objetivo

Criar **processo executavel sem a pessoa original**.

### Por Que SOPs Tradicionais Falham

| SOP Tradicional | SOP Inteligente |
|-----------------|-----------------|
| Documento estatico | Sistema vivo com IA |
| "Faca isso" | "Faca isso + valide com este prompt" |
| Ninguem le | IA executa/valida |
| Desatualiza rapido | Prompt atualiza facil |

### Estrutura de SOP Inteligente

```
1. OBJETIVO
   O que este processo entrega?

2. PASSO A PASSO
   Sequencia de acoes (max 10 passos)

3. CRITERIOS DE QUALIDADE
   Como saber se esta certo?

4. PROMPT DE EXECUCAO/VALIDACAO
   IA que executa ou valida cada passo

5. CHECKLIST FINAL
   Verificacao antes de entregar
```

### Conteudo (Estrutura de Aula)

| Etapa | Duracao | Conteudo |
|-------|---------|----------|
| **1. Contexto** | 5 min | "Seu melhor funcionario vai sair. O processo morre?" |
| **2. Por que SOPs falham** | 10 min | Estaticos, ignorados, desatualizados |
| **3. Estrutura SOP Inteligente** | 10 min | 5 componentes obrigatorios |
| **4. Exemplo antes/depois** | 5 min | SOP tradicional → SOP com IA |
| **5. Como testar se funciona** | 5 min | Dar para alguem novo e medir |
| **6. Build Sprint** | 45 min | Criar 1 SOP Inteligente |
| **7. Proxima acao 48h** | 5 min | Testar com 1 pessoa + ajustar |

### Entregavel Obrigatorio

**1 SOP Inteligente completo**, com:

- Objetivo claro (1 frase)
- Passo a passo (5-10 passos)
- Criterios de qualidade (3-5 criterios)
- Prompt de execucao/validacao
- Checklist final

### Template

```markdown
# SOP: [Nome do Processo]

## Objetivo
Entregar [resultado] em [tempo] com [qualidade].

## Passo a Passo
1. [Acao 1]
2. [Acao 2]
3. [Acao 3]
...

## Criterios de Qualidade
- [ ] [Criterio 1]
- [ ] [Criterio 2]
- [ ] [Criterio 3]

## Prompt de Validacao
```
Revise este [artefato] e verifique:
1. [Criterio 1]
2. [Criterio 2]
3. [Criterio 3]

Se passar em todos, diga "APROVADO".
Se falhar, liste o que precisa corrigir.
```

## Checklist Final
- [ ] Passou no prompt de validacao
- [ ] Testado com pessoa nova
- [ ] Documentado em [local]
```

### Prompt IA (Geracao de SOP)

```
Crie um SOP detalhado para este processo:
[descrever processo]

Inclua:
- Objetivo (1 frase)
- Passos claros (max 10)
- Erros comuns e como evitar
- Criterios de qualidade (3-5)
- Prompt de IA para executar ou revisar cada passo
- Checklist final

Formato: Markdown estruturado
```

---

## MODULO 4: Delegar Sem Virar Gargalo

### Ficha Tecnica

| Atributo | Valor |
|----------|-------|
| **Duracao** | 90 minutos |
| **Bloom** | Nivel 5 - Avaliar |
| **Formato** | Video (30min) + Build Sprint (60min) |

### Objetivo

Eliminar retrabalho e microgestao usando IA como "camada intermediaria".

### Por Que Delegar Falha

| Problema | Causa Raiz | Solucao |
|----------|------------|---------|
| "Ficou ruim" | Briefing vago | Template de briefing |
| "Demorou demais" | Sem prazo claro | Deadline no briefing |
| "Tive que refazer" | Sem criterios | Checklist de qualidade |
| "So funciona comigo" | Sem validacao | Prompt de IA valida antes |

### Modelo de Delegacao Assistida

```
TAREFA → BRIEFING → CHECKLIST → [IA VALIDA] → HUMANO EXECUTA → [IA VALIDA] → ENTREGA
```

### Conteudo (Estrutura de Aula)

| Etapa | Duracao | Conteudo |
|-------|---------|----------|
| **1. Contexto** | 5 min | "Quanto tempo voce gasta revisando trabalho dos outros?" |
| **2. Por que delegar falha** | 10 min | Briefing → Execucao → Validacao |
| **3. Delegacao = criterios + validacao** | 10 min | Nao e "confianca", e sistema |
| **4. Modelo de delegacao assistida** | 5 min | IA como camada intermediaria |
| **5. Exemplo pratico** | 10 min | Marketing / Atendimento / Ops |
| **6. Build Sprint** | 45 min | Criar 1 Modelo de Delegacao |
| **7. Proxima acao 48h** | 5 min | Delegar 1 tarefa com o modelo |

### Entregavel Obrigatorio

**Modelo de Delegacao Assistida**, contendo:

| Componente | Descricao |
|------------|-----------|
| **Tarefa** | O que deve ser feito |
| **Briefing** | Contexto + objetivo + restricoes |
| **Checklist** | Criterios de qualidade |
| **Prompt de Validacao** | IA valida antes de chegar em voce |
| **Output Esperado** | Exemplo do resultado correto |

### Template

```markdown
# Delegacao: [Nome da Tarefa]

## Tarefa
[Descricao clara do que fazer]

## Briefing
- Contexto: [por que estamos fazendo isso]
- Objetivo: [resultado esperado]
- Restricoes: [o que NAO pode]
- Prazo: [quando precisa estar pronto]
- Recursos: [onde encontrar informacao]

## Checklist de Qualidade
- [ ] [Criterio 1]
- [ ] [Criterio 2]
- [ ] [Criterio 3]

## Prompt de Validacao (IA)
```
Revise esta entrega:
[colar entrega]

Verifique:
1. [Criterio 1]
2. [Criterio 2]
3. [Criterio 3]

Se TODOS ok: responda "APROVADO - pode entregar"
Se ALGUM falhar: liste o que corrigir antes de entregar
```

## Output Esperado
[Exemplo ou referencia do resultado correto]
```

### Prompt IA (Criar Modelo de Delegacao)

```
Quero delegar esta tarefa:
[descrever tarefa]

Crie:
1. Briefing claro (contexto + objetivo + restricoes + prazo)
2. Checklist de qualidade (5-7 criterios)
3. Prompt de IA para validar ANTES de chegar em mim
4. Exemplo de output esperado

Objetivo: eliminar 80% das revisoes manuais.
```

---

## MODULO 5: Pessoas Custam Dinheiro — Decida com Numeros

### Ficha Tecnica

| Atributo | Valor |
|----------|-------|
| **Duracao** | 90 minutos |
| **Bloom** | Nivel 5 - Avaliar |
| **Formato** | Video (30min) + Build Sprint (60min) |

### Objetivo

Tomar decisao racional sobre **manter, automatizar ou eliminar funcoes**.

### Framework de Decisao

```
CUSTO ATUAL → CUSTO COM IA → DELTA → RISCO → DECISAO
```

### Matriz de Decisao

| Cenario | Custo Alto + Decisoes Repetitivas | Acao |
|---------|-----------------------------------|------|
| A | Sim | Automatizar com IA |
| B | Custo alto, decisoes estrategicas | Manter + capacitar |
| C | Custo baixo, repetitivo | Manter (ROI nao compensa) |
| D | Custo baixo, estrategico | Manter (critico) |

### Conteudo (Estrutura de Aula)

| Etapa | Duracao | Conteudo |
|-------|---------|----------|
| **1. Contexto** | 5 min | "Quanto custa REALMENTE cada pessoa?" |
| **2. Custo total de funcionario** | 10 min | Salario + encargos + gestao + erro |
| **3. Framework de decisao** | 10 min | Manter / Automatizar / Eliminar |
| **4. Como calcular ROI de automacao** | 10 min | Custo IA vs Custo humano |
| **5. Build Sprint** | 45 min | Analise de ROI para 3 funcoes |
| **6. Plano de acao** | 10 min | Decisao + cronograma |

### Entregavel Obrigatorio

**Analise de ROI de Pessoas**, contendo:

| Coluna | Descricao |
|--------|-----------|
| **Funcao** | Nome do cargo |
| **Custo Anual** | Salario + encargos + custos indiretos |
| **Horas/Semana** | Tempo dedicado |
| **Decisoes Cobertas** | Quais decisoes essa pessoa toma |
| **Alternativa IA** | O que a IA faria |
| **Custo IA** | Ferramentas + implementacao + manutencao |
| **Economia Estimada** | Delta anual |
| **Risco** | O que pode dar errado |
| **Recomendacao** | Manter / Automatizar / Eliminar |

### Template

```
| Funcao | Custo/Ano | Horas | Decisoes | Alt. IA | Custo IA | Economia | Risco | Acao |
|--------|-----------|-------|----------|---------|----------|----------|-------|------|
| SDR | R$ 84K | 40h | Qualificar leads | Bot IA | R$ 12K | R$ 72K | Medio | AUTOMATIZAR |
| Gerente | R$ 180K | 50h | Estrategia | - | - | - | Alto | MANTER |
| Assistente | R$ 36K | 30h | Triagem | n8n | R$ 3K | R$ 33K | Baixo | AUTOMATIZAR |
```

### Prompt IA (Analise de ROI)

```
Com base nesses dados:
- Funcao: [cargo]
- Salario: [valor]
- Horas/semana: [numero]
- Principais tarefas: [lista]
- Decisoes que toma: [lista]

Calcule:
1. Custo anual total (salario + 80% encargos + 20% gestao)
2. Quais tarefas podem ser automatizadas com IA
3. Custo estimado da automacao (ferramentas + setup)
4. Economia anual potencial
5. Riscos da automacao
6. Recomendacao final: MANTER / AUTOMATIZAR / ELIMINAR
```

---

# PARTE 3: PROJETO FINAL

## Sistema de Reducao de Dependencia Humana

### Descricao

Ao final da trilha, o aluno tera um **sistema completo** para:
1. Mapear riscos de dependencia
2. Identificar decisoes automatizaveis
3. Documentar processos com IA
4. Delegar sem microgestao
5. Decidir sobre headcount com dados

### Entregaveis do Projeto Final

| Entregavel | Origem | Criterio de Aprovacao |
|------------|--------|----------------------|
| Mapa de Dependencia Humana | Modulo 1 | >= 10 funcoes, >= 2 riscos altos |
| Matriz Funcao x Decisao | Modulo 2 | >= 10 decisoes, >= 3 automatizaveis |
| 3 SOPs Inteligentes | Modulo 3 | Com prompt de validacao funcional |
| 2 Modelos de Delegacao | Modulo 4 | Testados com 1 tarefa real |
| Analise de ROI | Modulo 5 | >= 3 funcoes analisadas |
| **Plano de Acao 90 dias** | Integracao | Cronograma + metricas |

### Rubrica de Avaliacao

| Criterio | Peso | Aprovado | Parcial | Reprovado |
|----------|------|----------|---------|-----------|
| Completude | 30% | Todos entregaveis | 70%+ | <70% |
| Qualidade | 30% | Passa em todos checklists | 70%+ | <70% |
| Aplicabilidade | 20% | Implementado no negocio | Planejado | Teorico |
| Impacto | 20% | Metrica melhorou | Baseline definido | Sem metrica |

---

# PARTE 4: RECURSOS E SUPORTE

## Kits de Aceleracao

| Modulo | Template | Prompt | Video |
|--------|----------|--------|-------|
| 1 | Mapa de Dependencia.xlsx | Prompt de Analise | Troubleshooting (5min) |
| 2 | Matriz Funcao-Decisao.xlsx | Prompt de Classificacao | Troubleshooting (5min) |
| 3 | Template SOP.md | Prompt de Geracao | Troubleshooting (5min) |
| 4 | Modelo Delegacao.md | Prompt de Validacao | Troubleshooting (5min) |
| 5 | Analise ROI.xlsx | Prompt de Calculo | Troubleshooting (5min) |

## Niveis de Uso

| Nivel | Tempo | O que faz |
|-------|-------|-----------|
| **1 - Empresario Apressado** | 15 min | Importa template, preenche, usa prompt |
| **2 - Funcionario Aprendendo** | 45 min | Assiste aula, constroi do zero |
| **3 - Expert Customizando** | 2h | Adapta para contexto especifico |

---

# PARTE 5: METRICAS DE SUCESSO

## KPIs da Trilha

| Metrica | Meta | Como Medir |
|---------|------|------------|
| Taxa de conclusao | >70% | Modulos concluidos / Iniciados |
| Entregaveis produzidos | 100% | Checklists aprovados |
| Implementacao real | >50% | Prova de implementacao (print/log) |
| Impacto no DRE | Mensuravel | Antes/depois documentado |

## Timeline de Resultados

| Marco | Prazo | Evidencia |
|-------|-------|-----------|
| Mapa de Dependencia pronto | 48h | Arquivo preenchido |
| 1 SOP Inteligente funcionando | 7 dias | Testado com pessoa nova |
| 1 Delegacao sem revisao | 14 dias | Tarefa aprovada pela IA |
| ROI calculado | 21 dias | Planilha completa |
| Decisao de headcount tomada | 30 dias | Acao implementada |

---

# PARTE 6: ALINHAMENTO COM ICP

## Checklist de Validacao GPS

### DESTINO
- [x] Deixa claro PARA ONDE o aluno vai? → Sistema anti-dependencia
- [x] Explica O QUE vai conseguir fazer? → 5 entregaveis especificos
- [x] Conecta com motivacao profunda? → "Negocio que funciona SEM mim"

### ORIGEM
- [x] Considera o nivel de conhecimento previo? → Iniciante (ChatGPT basico)
- [x] Nao assume conhecimentos que o aluno nao tem? → Templates prontos
- [x] Considera limitacoes (tempo, atencao)? → 90min/modulo, entrega em 48h

### ROTA
- [x] Sequencia segue progressao logica? → Diagnostico → Priorizacao → Documentacao → Execucao → Decisao
- [x] Evita saltos de complexidade? → Cada modulo usa o anterior
- [x] E conciso (sem prolixidade)? → Max 2-3 conceitos por aula
- [x] Conecta cada conceito ao objetivo final? → Sempre volta ao DRE

---

**Documento elaborado por:** Course Architect Agent
**Base:** ICP Nova Formacao + Documento nova-formacao
**Versao:** 1.0
**Data:** Dezembro 2025
